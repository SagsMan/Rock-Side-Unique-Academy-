<?php

/* 
	------------------------------------------------------------------------	  
	Copyright (C) foBrain Tech LTD (Igweze Ebele Mark) 2010 - 2026.

	Licensed under the Apache License, Version 2.0 (the 'License');
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an 'AS IS' BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License		 
	------------------------------------------------------------------------ 
	foBrain Open Source & wizGrade Open Source App is designed & developed 
	by Igweze Ebele Mark for foBrain Tech LTD

	foBrain School App is Dedicated To Almighty God, My Amazing Parents, 
	To My Fabulous and Supporting Wife Nkiruka J.
	To My Inestimable Kids Osinachi, Ifechukwu, Naetochukwu & Chimamanda.  
	------------------------------------------------------------------------
	WEBSITE 					PHONES/WHATSAPP			EMAILS
	https://www.fobrain.com		+234 - 80 30 716 751  	igweze@fobrain.com	 
	https://www.fobrain.ng		+234 - 80 22 000 490	support@fobrain.com 
	------------------------------------------------------------------------
	
	
	-------- Script Description --------
	This page is manually add result manager
	------------------------------------------------------------------------*/ 


		if (!defined('fobrain')) /* This checks if this page was wrongly access by users */

		die('Hahahaha, Hacking attempt . . . . Be Careful . . . . You Are Been Warned !!!!');
				
		require_once $fobrainIconPage; /* This include top middle global icon page eg go back, print buttons etcs */

?> 
 		
		<!-- row -->
		<div <?php echo $fob_view; ?> class="row gutters row-section fobrain-section-div justify-content-center">
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">	
				<!-- card start -->
				<div class="card card-shadow"> 
					<?php 
					$page_title = '<i class="mdi mdi-format-list-checks fs-18"></i> 
							Upload Student Result';
						pageTitle($page_title, 0);	 
					?>	
					<div id="msg-box"></div> 					
					<div class="card-body"> 

						<div class="gutters my-15 text-end"> 
							<button type="button" class="wiz-toggle-1 btn btn-primary display-none" >
								<i class="mdi mdi-cloud-upload label-icon"></i>   Single Upload
							</button>
							<button type="button" class="wiz-toggle-2 btn btn-danger">
								<i class="mdi mdi-upload-multiple label-icon"></i>   Bulk Upload
							</button>  
						</div> 
						<hr class="my-15 text-danger" />
						<form class="form-horizontal" id="frmload-result" role="form">
							<div class="row gutters mb-25 mt-10">
								<div class="hints">
									[<i class="mdi mdi-help-circle-outline"></i>] 
									Upload student results
								</div>
							</div>

							<?php $show_all = 0; require ($fobrainAdminGlobalDir.'common-frm-1.php'); ?> 

							<!-- row -->
							<div class="row gutters">
								<div class="col-lg-12">										
									<!-- field wrapper start -->
									<div class="field-wrapper">
										<select class="form-control fob-select"  id="term1" name="term" required placeholder="Select term">
											
											<option value = "">Please select One</option>

											<?php
											
												try {
												
													$curTerm = currentSessionTerm($conn);    /* current school term  */
										
												}catch(PDOException $e) {
					
													fobrainDie( 'Ooops Database Error: ' . $e->getMessage());
					
												}  
												foreach($term_list as $term_key => $term_value){    /* loop array */

													if ($curTerm == $term_key){
														$selected = "SELECTED";
													} else {
														$selected = "";
													}

													echo '<option value="'.$term_key.'"'.$selected.'>'.$term_value.'</option>' ."\r\n";

												}

											?>
										
										</select>
										<div class="field-placeholder"> School Term <span class="text-danger">*</span></div>
									</div>
									<!-- field wrapper end -->
								</div>									 
							</div>	
							<!-- /row -->
							
							<!-- row -->
							<div class="row gutters mt-30">
								<div class="col-12 text-end">
									<input type="hidden" name="result" value="load" />
									<button type="submit" class="btn btn-primary waves-effect   
									btn-label waves-light" id="load-result"> 
										<i class="mdi mdi-account-search label-icon"></i> Search
									</button>
								</div>
							</div>	
							<!-- /row --> 

						</form>
						<!-- /form --> 


						
						<form class="form-horizontal display-none" id = "frmbulk-excel-result"  enctype="multipart/form-data" 
							action='bulk-rs-upload.php'  method="POST" role="form">	 

							<div class="row gutters mb-25 mt-10">
								<div class="hints">
									[<i class="mdi mdi-help-circle-outline"></i>] 
									Work offline and upload bulk students result at once using Excel file
								</div>
							</div>
							<?php $show_all = 0; require ($fobrainAdminGlobalDir.'common-frm-1.php'); ?>

							<!-- row -->
							<div class="row gutters">
								<div class="col-lg-12">										
									<!-- field wrapper start -->
									<div class="field-wrapper">
										<select class="form-control fob-select"  id="term2" name="term" required>
											
											<option value = "">Please select One</option>

											<?php
											
												try {
												
													$curTerm = currentSessionTerm($conn);    /* current school term  */
										
												}catch(PDOException $e) {
					
													fobrainDie( 'Ooops Database Error: ' . $e->getMessage());
					
												}  
												foreach($term_list as $term_key => $term_value){    /* loop array */

													if ($curTerm == $term_key){
														$selected = "SELECTED";
													} else {
														$selected = "";
													}

													echo '<option value="'.$term_key.'"'.$selected.'>'.$term_value.'</option>' ."\r\n";

												}

											?>
										
										</select>
										<div class="field-placeholder"> School Term <span class="text-danger">*</span></div>
									</div>
									<!-- field wrapper end -->
								</div>									 
							</div>	
							<!-- /row -->
							
							<!-- row -->
							<div class="row gutters justify-content-center my-10"> 
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 text-center">
									<div class="picture-div mb-10">
										<img src="<?php echo $wiz_df_xls_img; ?>" id="preview-picture" alt="school logo" class="img-h-160 rounded img-thumbnail" />
									</div>
									<!-- file-wrapper start -->
									<div class="file-wrapper component-free">
										<label class="upload fob-btn-div">
											<i class="mdi mdi-cloud-upload-outline fs-36 text-danger link-pointer"></i> 
											<input type="file" name="uploadPic" id="bulkRSExcel" class="form-control hide">
										</label> 
										<div class="form-text fob-btn-div"> 
											<input type="hidden" name="uMode" value="1" />
											<input type="hidden" name="query" value="upload" />
											<div class="fs-14 fw-600 mb-10">Upload Excel File</div>
											<div class="text-danger">Only max image size of 2MB &amp; format of <?php echo $allowedExcelExt; ?> are allowed.</div>
										</div>

										<div class="display-none mb-3 fob-btn-loader login-pro-px">
											<strong role="status">Processing...</strong>
											<div class="spinner-border ms-auto" aria-hidden="true"></div>
										</div> 
									</div>
									<!-- file-wrapper end -->
								</div> 
							</div>
							<!-- /row -->
 

						</form>
						<!-- /form --> 

					</div>
				</div>
				<!-- card end -->	
			</div>
		</div>
		<!-- / row -->	  

		<!-- row -->
		<div class="row gutters <?php echo $fob_view_2; ?>" id="wiz-slider">	
			<div class="col-lg-12">		
				<div class=" mx-10" id="fobrain-page-div"></div>				 		
			</div>												
		</div>
		<!-- / row -->				

		<!--  fobrain modal start -->			
		<button type="button" class="btn modal-fobrain  display-none"  data-bs-toggle="modal" data-bs-target="#modal-fobrain"></button>				
		<!-- Scrollable modal -->
		<div class="modal fade animate__animated animate__zoomInDown" id="modal-fobrain" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-scrollable  modal-xl">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalScrollableTitle">
							Result Manager
						</h5> 								 
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div id="edit-msg"> </div>
					<div class="modal-body">
						<div id="modal-load-div"></div> 
					</div>
					<div class="modal-footer">
						<button type="button" id="close-modal" class="btn btn-danger close-modal" data-bs-dismiss="modal">Close</button>
					</div>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->
		<!-- fobrain modal end -->	


		<script>

			$('body').on('click','.wiz-toggle-1',function(event){  /* toggle div 1 */
				
				event.stopImmediatePropagation();	
				
				$('.wiz-toggle-2, #frmload-result').fadeIn(1000); 
				$('.wiz-toggle-1, #frmbulk-excel-result').fadeOut(1000);   
				
				return false;  

			});
			

			$('body').on('click','.wiz-toggle-2',function(event){  /* toggle div 2 */

				event.stopImmediatePropagation();	  
				
				$('.wiz-toggle-1, #frmbulk-excel-result').fadeIn(1000); 
				$('.wiz-toggle-2, #frmload-result').fadeOut(1000); 
				
				return false;  

			}); 
		 
			$('.fob-select').each(function() {  
				renderSelect($('#'+this.id)); 
			});
		</script>	
		
		<?php

			if($component_free == 1){

				$msg_i = "* Ooops, your account does not support this module. Please upgrade to access these features.";
				 
				echo $infoMsg.$msg_i.$iEnd; 
				echo "<script type='text/javascript'>   
						$('.component-free').hide();
				</script>";

			}

		?>