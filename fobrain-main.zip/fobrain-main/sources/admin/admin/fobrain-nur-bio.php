<?php

/* 
	------------------------------------------------------------------------	  
	Copyright (C) foBrain Tech LTD (Igweze Ebele Mark) 2010 - 2026.

	Licensed under the Apache License, Version 2.0 (the 'License');
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an 'AS IS' BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License		 
	------------------------------------------------------------------------ 
	foBrain Open Source & wizGrade Open Source App is designed & developed 
	by Igweze Ebele Mark for foBrain Tech LTD

	foBrain School App is Dedicated To Almighty God, My Amazing Parents, 
	To My Fabulous and Supporting Wife Nkiruka J.
	To My Inestimable Kids Osinachi, Ifechukwu, Naetochukwu & Chimamanda.  
	------------------------------------------------------------------------
	WEBSITE 					PHONES/WHATSAPP			EMAILS
	https://www.fobrain.com		+234 - 80 30 716 751  	igweze@fobrain.com	 
	https://www.fobrain.ng		+234 - 80 22 000 490	support@fobrain.com 
	------------------------------------------------------------------------
	
	
*/ 

		if (!defined('fobrain')) /* This checks if this page was wrongly access by users */

		die('Hahahaha, Hacking attempt . . . . Be Careful . . . . You Are Been Warned !!!!');
				
		require_once $fobrainIconPage; /* This include top middle global icon page eg go back, print buttons etcs */

		/* check student entry level  */	
		
		if($en_level == 1) {
					
			$class_1 = $class; $class_2 = $class; $class_3 = $class; 
		
		}elseif($en_level == 2) {
		
			$class_1 = ''; $class_2 = $class; $class_3 = $class; 
		
		}elseif($en_level == 3) {
		
			$class_1 = ''; $class_2 = ''; $class_3 = $class; 					
		
		}else{ }  

			$conn->beginTransaction();	/* begin PDO transaction and prepare student data insertion across database tables */			 


			$ebele_mark_1 = "INSERT INTO  $i_reg_tb 
			
								(nk_regno, class_1, class_2, class_3,  
								en_level, en_term, session_id, date_regs, active)

								VALUES (:nk_regno, :class_1, :class_2, :class_3, 
										:en_level, :en_term, :session_id, :date_regs, :active)";
													
			$igweze_prep_1 = $conn->prepare($ebele_mark_1);
			$igweze_prep_1->bindValue(':nk_regno', $regNum);
			$igweze_prep_1->bindValue(':class_1', $class_1);
			$igweze_prep_1->bindValue(':class_2', $class_2);
			$igweze_prep_1->bindValue(':class_3', $class_3);
			$igweze_prep_1->bindValue(':en_level', $en_level);
			$igweze_prep_1->bindValue(':en_term', $en_term);
			$igweze_prep_1->bindValue(':session_id', $sessionID);
			$igweze_prep_1->bindValue(':date_regs', $regDate);
			$igweze_prep_1->bindValue(':active', $foreal);				 				 
			$igweze_prep_1->execute();
			
			$regID = $conn->lastInsertId(); /* new student reg number ID that will be added across all tables */
			 
			if($regID == ""){

				$conn->rollBack(); /* if everything is not alright then don't insert student data accross tables */
				$msg_e = "Ooops Critical Error, Error(480) Has Just Occur,  If This Error Persist, Please Contact The Developer";
				echo "<script type='text/javascript'>  hidePageLoader();  </script>";

			}

			if($show_tasks_div == $fiVal){ /* check if student registration is from manual input registration  */
				
				
				$ebele_mark_2 = "INSERT INTO $i_student_tb (ireg_id, i_accesspass , i_salted, i_sponsor_ac,
															i_sponsor_p, i_firstname, i_midname, i_lastname)

								VALUES (:ireg_id, :i_accesspass , :i_salted, :i_sponsor_ac, :i_sponsor_p,
											:i_firstname, :i_midname, :i_lastname)"; //:i_stupic,
														
				$igweze_prep_2 = $conn->prepare($ebele_mark_2);
				$igweze_prep_2->bindValue(':ireg_id', $regID);
				$igweze_prep_2->bindValue(':i_accesspass', $userPass);
				$igweze_prep_2->bindValue(':i_salted', $userPass);
				$igweze_prep_2->bindValue(':i_sponsor_ac', $userPass);				 				 
				$igweze_prep_2->bindValue(':i_sponsor_p', $spon_access);				 				 
				$igweze_prep_2->bindValue(':i_firstname', $fname);				 				 
				$igweze_prep_2->bindValue(':i_midname', $mname);				 				 
				$igweze_prep_2->bindValue(':i_lastname', $lname);
				$igweze_prep_2->execute(); 
			
			}elseif($show_tasks_div == $thVal){ /* check if student registration is from manual input registration  */
				
				$ebele_mark_2 = "INSERT INTO $i_student_tb (ireg_id, i_accesspass, i_salted, i_sponsor_ac,
								i_sponsor_p, i_firstname, i_midname, i_lastname, i_gender, i_dob, i_country, 
                                i_state, i_city, i_add_fi, i_stu_phone, i_email)

									VALUES (:ireg_id, :i_accesspass , :i_salted, :i_sponsor_ac, :i_sponsor_p,
											:i_firstname, :i_midname, :i_lastname, :i_gender, :i_dob, :i_country,
                                            :i_state, :i_city, :i_add_fi, :i_stu_phone, :i_email)";
														
				$igweze_prep_2 = $conn->prepare($ebele_mark_2);
				$igweze_prep_2->bindValue(':ireg_id', $regID); 
				$igweze_prep_2->bindValue(':i_accesspass', $userPass);
				$igweze_prep_2->bindValue(':i_salted', $userPass);
				$igweze_prep_2->bindValue(':i_sponsor_ac', $userPass);				 				 
				$igweze_prep_2->bindValue(':i_sponsor_p', $spon_access);				 				 
				$igweze_prep_2->bindValue(':i_firstname', $fname);				 				 
				$igweze_prep_2->bindValue(':i_midname', $mname);				 				 
				$igweze_prep_2->bindValue(':i_lastname', $lname);
				$igweze_prep_2->bindValue(':i_gender', $gender);
				$igweze_prep_2->bindValue(':i_dob', $dob); 
				$igweze_prep_2->bindValue(':i_country', $country);
				$igweze_prep_2->bindValue(':i_state', $state);
				$igweze_prep_2->bindValue(':i_city', $city);
				$igweze_prep_2->bindValue(':i_add_fi', $add1); 
				$igweze_prep_2->bindValue(':i_stu_phone', $phone);
				$igweze_prep_2->bindValue(':i_email', $email); 
				$igweze_prep_2->execute();
			
			}else{ /* student /* remove this student information from online registration records | is either from excel bulk upload or online registraion admission */
				
				$ebele_mark_2 = "INSERT INTO $i_student_tb (ireg_id, i_stupic, i_accesspass, i_salted, i_sponsor_ac,
								i_sponsor_p, i_firstname, i_midname, i_lastname, i_gender, i_dob, bloodgp,
								genotype, i_country, i_state, i_lga, i_city, i_add_fi, i_add_se,
								i_stu_phone, i_email, hostel, route, i_sponsor, i_spo_phone, i_spon_occup,i_spo_add)

									VALUES (:ireg_id, :i_stupic, :i_accesspass , :i_salted, :i_sponsor_ac, :i_sponsor_p,
											:i_firstname, :i_midname, :i_lastname, :i_gender, :i_dob, :bloodgp, 
											:genotype,  :i_country, :i_state, :i_lga, :i_city, :i_add_fi,
											:i_add_se, :i_stu_phone, :i_email, :hostel, :route, :i_sponsor, :i_spo_phone, 
											:i_spon_occup, :i_spo_add)";
														
				$igweze_prep_2 = $conn->prepare($ebele_mark_2);
				$igweze_prep_2->bindValue(':ireg_id', $regID);
				$igweze_prep_2->bindValue(':i_stupic', $applyPic);
				$igweze_prep_2->bindValue(':i_accesspass', $userPass);
				$igweze_prep_2->bindValue(':i_salted', $userPass);
				$igweze_prep_2->bindValue(':i_sponsor_ac', $userPass);				 				 
				$igweze_prep_2->bindValue(':i_sponsor_p', $spon_access);				 				 
				$igweze_prep_2->bindValue(':i_firstname', $fname);				 				 
				$igweze_prep_2->bindValue(':i_midname', $mname);				 				 
				$igweze_prep_2->bindValue(':i_lastname', $lname);
				$igweze_prep_2->bindValue(':i_gender', $gender);
				$igweze_prep_2->bindValue(':i_dob', $dob);
				$igweze_prep_2->bindValue(':bloodgp', $bloodGP);
				$igweze_prep_2->bindValue(':genotype', $genoTP);
				//$igweze_prep_2->bindValue(':disability', $disability);
				$igweze_prep_2->bindValue(':i_country', $country);
				$igweze_prep_2->bindValue(':i_state', $state);
				$igweze_prep_2->bindValue(':i_lga', $lga);
				$igweze_prep_2->bindValue(':i_city', $city);
				$igweze_prep_2->bindValue(':i_add_fi', $add1);
				$igweze_prep_2->bindValue(':i_add_se', $add2);
				$igweze_prep_2->bindValue(':i_stu_phone', $phone);
				$igweze_prep_2->bindValue(':i_email', $email);
				$igweze_prep_2->bindValue(':hostel', $hostelID);
				$igweze_prep_2->bindValue(':route', $routeID);
				$igweze_prep_2->bindValue(':i_sponsor', $spon);
				$igweze_prep_2->bindValue(':i_spo_phone', $sphone);
				$igweze_prep_2->bindValue(':i_spon_occup', $soccup);
				$igweze_prep_2->bindValue(':i_spo_add', $adds);
				$igweze_prep_2->execute();
			}
			
			$ebele_mark_3 = "INSERT INTO $class_one_sdoracle_score_tb  (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_3 = $conn->prepare($ebele_mark_3);
			$igweze_prep_3->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_3->execute();
			

			$ebele_mark_3_1 = "INSERT INTO $class_one_sdoracle_comment_tb  (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_3_1 = $conn->prepare($ebele_mark_3_1);
			$igweze_prep_3_1->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_3_1->execute(); 
			

			$ebele_mark_4 = "INSERT INTO $class_one_sub_score_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_4 = $conn->prepare($ebele_mark_4);
			$igweze_prep_4->bindValue(':ireg_id', $regID);		 				 
			$igweze_prep_4->execute();


			$ebele_mark_5 = "INSERT INTO $class_one_sdoracle_grade_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_5 = $conn->prepare($ebele_mark_5);
			$igweze_prep_5->bindValue(':ireg_id', $regID);
			$igweze_prep_5->execute();


			$ebele_mark_6 = "INSERT INTO $class_one_sdoracle_grand_score_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_6 = $conn->prepare($ebele_mark_6);
			$igweze_prep_6->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_6->execute();


			$ebele_mark_7 = "INSERT INTO $class_one_class_remarks_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_7 = $conn->prepare($ebele_mark_7);
			$igweze_prep_7->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_7->execute();


			$ebele_mark_8 = "INSERT INTO $class_two_sdoracle_score_tb  (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_8 = $conn->prepare($ebele_mark_8);
			$igweze_prep_8->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_8->execute();

			
			$ebele_mark_8_1 = "INSERT INTO $class_two_sdoracle_comment_tb  (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_8_1 = $conn->prepare($ebele_mark_8_1);
			$igweze_prep_8_1->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_8_1->execute(); 
			
			
			$ebele_mark_9 = "INSERT INTO $class_two_sub_score_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_9 = $conn->prepare($ebele_mark_9);
			$igweze_prep_9->bindValue(':ireg_id', $regID);		 				 
			$igweze_prep_9->execute();


			$ebele_mark_10 = "INSERT INTO $class_two_sdoracle_grade_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_10 = $conn->prepare($ebele_mark_10);
			$igweze_prep_10->bindValue(':ireg_id', $regID);
			$igweze_prep_10->execute();


			$ebele_mark_11 = "INSERT INTO $class_two_sdoracle_grand_score_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_11 = $conn->prepare($ebele_mark_11);
			$igweze_prep_11->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_11->execute();


			$ebele_mark_12 = "INSERT INTO $class_two_class_remarks_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_12 = $conn->prepare($ebele_mark_12);
			$igweze_prep_12->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_12->execute();

			$ebele_mark_13 = "INSERT INTO $class_three_sdoracle_score_tb  (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_13 = $conn->prepare($ebele_mark_13);
			$igweze_prep_13->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_13->execute();


			$ebele_mark_13_1 = "INSERT INTO $class_three_sdoracle_comment_tb  (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_13_1 = $conn->prepare($ebele_mark_13_1);
			$igweze_prep_13_1->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_13_1->execute(); 

			
			$ebele_mark_14 = "INSERT INTO $class_three_sub_score_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_14 = $conn->prepare($ebele_mark_14);
			$igweze_prep_14->bindValue(':ireg_id', $regID);		 				 
			$igweze_prep_14->execute();


			$ebele_mark_15 = "INSERT INTO $class_three_sdoracle_grade_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_15 = $conn->prepare($ebele_mark_15);
			$igweze_prep_15->bindValue(':ireg_id', $regID);
			$igweze_prep_15->execute();


			$ebele_mark_16 = "INSERT INTO $class_three_sdoracle_grand_score_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_16 = $conn->prepare($ebele_mark_16);
			$igweze_prep_16->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_16->execute();


			$ebele_mark_17 = "INSERT INTO $class_three_class_remarks_tb (ireg_id)

								VALUES (:ireg_id)";
													
			$igweze_prep_17 = $conn->prepare($ebele_mark_17);
			$igweze_prep_17->bindValue(':ireg_id', $regID);				 				 
			$igweze_prep_17->execute();


			
			if (($igweze_prep_1 == true) && ($igweze_prep_2 == true) && ($igweze_prep_3 == true) && ($igweze_prep_3_1 == true) 
				&& ($igweze_prep_4 == true) && ($igweze_prep_5 == true) && ($igweze_prep_6 == true) 
				&& ($igweze_prep_7 == true) && ($igweze_prep_8 == true) && ($igweze_prep_8_1 == true) && ($igweze_prep_9 == true) 
				&& ($igweze_prep_10 == true) && ($igweze_prep_11 == true) && ($igweze_prep_12 == true)
				&& ($igweze_prep_13 == true) && ($igweze_prep_13_1 == true) && ($igweze_prep_14 == true) && ($igweze_prep_15 == true) 
				&& ($igweze_prep_16 == true) && ($igweze_prep_17 == true) ){

					
				if($show_tasks_div == $fiVal){ /* check if student registration is from manual input */

					$conn->commit(); /* if everything is alright then insert student data accross tables */
					
$new_profile =<<<IGWEZE

					<div class="table-responsive">
						<!-- table -->
						<table class='table table-hover table-responsive style-table mb-100'>
						<thead>
							<tr>
								<th>Reg No.</th> 
								<th>Name</th>
								<th>Tasks</th>
							</tr>
						</thead> 
						<tbody>  
							<tr>		
								<td> <a href='javascript:;' id='$regNum' class ='view-student'>$regNum </a> </td>
								<td> 
									<a href='javascript:;' id='$regNum' class ='view-student'>  
										<div class="d-flex align-items-center">
											<div class="flex-shrink-0 me-3" id = 'loadNewPic-$regNum'>
												<img src = "$wiz_default_img" class=" img-h-50 img-circle img-thumbnail">
											</div>
											<div class="flex-grow-1 text-primary" id = 'loadNewName-$regNum'>
												$lname $fname $mname
											</div>
										</div>	 
									</a> 
								</td>   
								<td>
									<div class="btn-group">
										<a href="javascript:;" class="btna btn-tasks  waves-effect waves-light dropdown-toggle p-5" data-bs-toggle="dropdown" aria-haspopup="true"
										data-bs-display="static" aria-expanded="false">
											<i class="mdi mdi-dots-grid align-middle fs-18"></i>
										</a> 
										<div class="dropdown-menu dropdown-menu-lg-end p-10 dropdown-shadow end-0 animate__animated animate__flipInY"> 
											<p class="mb-10">
												<a href='javascript:;' id='$regNum' class ='view-student text-sienna btn waves-effect btn-label waves-light'>									
													<i class="mdi mdi-text-box-search label-icon"></i> View 
												</a>	
											</p>
											<p class="mb-10">
												<a href='javascript:;' id='$regNum' class ='edit-profile text-slateblue btn waves-effect btn-label waves-light'>									
													<i class="mdi mdi-square-edit-outline label-icon"></i> Edit
												</a>	
											</p> 
											<p class="mb-10">
												<a href='javascript:;' id='$regNum' class ='student-id-card text-primary btn waves-effect btn-label waves-light'>									
													<i class="mdi mdi-square-edit-outline label-icon"></i> ID Card
												</a>	
											</p> 
											<p>
												<a href='javascript:;' id='$regNum' class ='reset-student text-danger btn waves-effect btn-label waves-light'>									
													<i class="mdi mdi-delete label-icon"></i> Reset
												</a>	
											</p> 
										</div>
									</div>    
								</td> 
							</tr> 
						</tbody>
						</table>
					</div> 
					
IGWEZE;

					echo $new_profile;
						
					//echo "<script type='text/javascript'> $('.edit-profile').trigger('click');</script>";
					
				}elseif($show_tasks_div == $seVal){
					
					$conn->commit(); /* if everything is alright then insert student data accross tables */
					
					$applyPicture = $applyPSrc.$applyPic;
					
					if (($applyPic != '') && (file_exists($applyPicture))){ 
					
						list($txt, $ext) = explode(".", $applyPic); 
						
						$session_fi = fobrainSession($conn, $sessionID);
						$session_se = $session_fi + $foreal;  
							
						$newPicPath = $school_pic_dir.$session_fi.'_'.$session_se.'/';
						
						$newPicName  = $regNum . randomString($charset, 10);
						$movePic = $newPicName.".".$ext;
						
						$movePicture = $newPicPath.$movePic;


						$ebele_mark_up = "UPDATE $i_student_tb 
						
										SET i_stupic = :i_stupic 
										
										WHERE ireg_id = :ireg_id";
											
						$igweze_prep_up = $conn->prepare($ebele_mark_up);
						$igweze_prep_up->bindValue(':ireg_id', $regID);
						$igweze_prep_up->bindValue(':i_stupic', $movePic);
						$igweze_prep_up->execute();

						copy($applyPicture, $movePicture);  
						unlink($applyPicture);		
					
					}
					
					removeRegistraion($conn, $stu_id); /* remove this student information from online registration records */
					$totalRegis = registrationCounter($conn);
				
					$msg_s = "Student <b>($lname $fname $mname)</b> was successfully  admitted into $schoolType with new <b> Reg No. $regNum</b>.";
				
				}elseif($show_tasks_div == $thVal){
					
					$conn->commit(); /* if everything is alright then insert student data accross tables */

									
$new_profile =<<<IGWEZE
		
  
					<tr>		
						<td> <a href='javascript:;' id='$regNum' class ='view-student'>$regNum </a> </td>
						<td> 
							<a href='javascript:;' id='$regNum' class ='view-student'>  
								<div class="d-flex align-items-center">
									<div class="flex-shrink-0 me-3" id = 'loadNewPic-$regNum'>
										<img src = "$wiz_default_img" class=" img-h-50 img-circle img-thumbnail">
									</div>
									<div class="flex-grow-1 text-primary" id = 'loadNewName-$regNum'>
										$lname $fname $mname
									</div>
								</div>	 
							</a> 
						</td>   
						<td>
							<div class="btn-group">
								<a href="javascript:;" class="btna btn-tasks  waves-effect waves-light dropdown-toggle p-5" data-bs-toggle="dropdown" aria-haspopup="true"
								data-bs-display="static" aria-expanded="false">
									<i class="mdi mdi-dots-grid align-middle fs-18"></i>
								</a> 
								<div class="dropdown-menu dropdown-menu-lg-end p-10 dropdown-shadow end-0 animate__animated animate__flipInY"> 
									<p class="mb-10">
										<a href='javascript:;' id='$regNum' class ='view-student text-sienna btn waves-effect btn-label waves-light'>									
											<i class="mdi mdi-text-box-search label-icon"></i> View 
										</a>	
									</p>
									<p class="mb-10">
										<a href='javascript:;' id='$regNum' class ='edit-profile text-slateblue btn waves-effect btn-label waves-light'>									
											<i class="mdi mdi-square-edit-outline label-icon"></i> Edit
										</a>	
									</p> 
									<p class="mb-10">
										<a href='javascript:;' id='$regNum' class ='student-id-card text-primary btn waves-effect btn-label waves-light'>									
											<i class="mdi mdi-square-edit-outline label-icon"></i> ID Card
										</a>	
									</p> 
									<p>
										<a href='javascript:;' id='$regNum' class ='reset-student text-danger btn waves-effect btn-label waves-light'>									
											<i class="mdi mdi-delete label-icon"></i> Reset
										</a>	
									</p> 
								</div>
							</div>    
						</td> 
					</tr>

		
IGWEZE;

					echo $new_profile;
				
				}else{
					
					$conn->rollBack(); /* if everything is not alright then don't insert student data accross tables */
					$msg_e = "Ooops Critical Error, Error(490) Has Just Occur,  If This Error Persist, Please Contact The Developer";

				} 

			}else{

				$conn->rollBack(); /* if everything is not alright then don't insert student data accross tables */
				$msg_e = "Ooops Critical Error, An Unknown Error(491) Has Just Occur, If This Error Persist,  Please Contact The Developer";

			} 

?>
